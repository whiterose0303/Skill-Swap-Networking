import  aiub.Form3;
import  aiub.Form4;
import  aiub.Form5;
import  aiub.Form8;
import  aiub.Form9;
import  aiub.Form10;
import  aiub.Form11;
import  aiub.Form12;
import  aiub.Form13;
public class Start 
{
    public static void main(String[] args)
    {
        Form3 f3 = new Form3();
        f3.setVisible(true);
    }
}
//javac Start.java

